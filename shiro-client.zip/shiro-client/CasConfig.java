package com.bootdo.system.shiro;

import org.jasig.cas.client.session.SingleSignOutFilter;
import org.jasig.cas.client.session.SingleSignOutHttpSessionListener;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @program hqjygl_dueval
 * @description:
 * @author: 肖振铎
 * @create: 2019/09/30 11:14
 */


@Configuration
public class CasConfig {

    @Bean
    public FilterRegistrationBean singleSignOutFilterRegistration() {
        FilterRegistrationBean registration = new FilterRegistrationBean(new SingleSignOutFilter());
        registration.addUrlPatterns("/*");
        return registration;
    }

    @Bean
    public ServletListenerRegistrationBean<SingleSignOutHttpSessionListener> singleSignOutListenerRegistration() {
        ServletListenerRegistrationBean<SingleSignOutHttpSessionListener> registration =
                new ServletListenerRegistrationBean<>(new SingleSignOutHttpSessionListener());
        return registration;
    }
}
